﻿using System;
using EstoqueVinheriaAgnello.Services;

class Program
{
    static void Main(string[] args)
    {
        EstoqueVinheria estoque = new EstoqueVinheria();
        string opcao;

        do
        {
            Console.WriteLine("\n--- ESTOQUE VINHERIA AGNELLO ---");
            Console.WriteLine("1 - Cadastrar Vinho");
            Console.WriteLine("2 - Entrada de Estoque");
            Console.WriteLine("3 - Saída de Estoque");
            Console.WriteLine("4 - Listar Vinhos");
            Console.WriteLine("5 - Atualizar Vinho");
            Console.WriteLine("6 - Remover Vinho");
            Console.WriteLine("0 - Sair");
            Console.Write("Escolha uma opção: ");
            opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":

                    Console.Write("\nDigite o Nome do Vinho (ex: Vinho Tinto Cabernet): ");
                    string nome = Console.ReadLine();

                    Console.Write("Digite o Tipo do Vinho (ex: Tinto, Branco, Rosé): ");
                    string tipo = Console.ReadLine();

                    int safra;
                    while (true)
                    {
                        try
                        {
                            Console.Write("Digite a Safra do Vinho (ex: 2020): ");
                            safra = int.Parse(Console.ReadLine());
                            break;
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Erro: A safra deve ser um número inteiro válido.");
                        }
                    }

                    int quantidade;
                    while (true)
                    {
                        try
                        {
                            Console.Write("Digite a Quantidade de Vinho (ex: 50): ");
                            quantidade = int.Parse(Console.ReadLine());
                            break;
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Erro: A quantidade deve ser um número inteiro válido.");
                        }
                    }

                    decimal preco;
                    while (true)
                    {
                        try
                        {
                            Console.Write("Digite o Preço do Vinho (ex: 120.50): ");
                            preco = decimal.Parse(Console.ReadLine());
                            break;
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Erro: O preço deve ser um número válido.");
                        }
                    }

                    estoque.CadastrarVinho(nome, tipo, safra, quantidade, preco);
                    Console.WriteLine("Vinho cadastrado com sucesso!");
                    break;

                case "2":
                    int idEntrada;
                    while (true)
                    {
                        try
                        {
                            Console.Write("Digite o ID do vinho para a entrada no estoque: ");
                            idEntrada = int.Parse(Console.ReadLine());
                            break;
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Erro: O ID deve ser um número inteiro.");
                        }
                    }

                    estoque.EntradaEstoque(idEntrada);
                    break;

                case "3":
                    int idSaida;
                    while (true)
                    {
                        try
                        {
                            Console.Write("Digite o ID do vinho para a saída do estoque: ");
                            idSaida = int.Parse(Console.ReadLine());
                            break;
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Erro: O ID deve ser um número inteiro.");
                        }
                    }

                    estoque.SaidaEstoque(idSaida);
                    break;

                case "4":
                    estoque.ListarVinhos();
                    break;

                case "5":
                    int idAtualizar;
                    while (true)
                    {
                        try
                        {
                            Console.Write("Digite o ID do vinho que deseja atualizar: ");
                            idAtualizar = int.Parse(Console.ReadLine());
                            break;
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Erro: O ID deve ser um número inteiro.");
                        }
                    }
                    estoque.AtualizarVinho(idAtualizar);
                    break;

                case "6":
                    int idRemover;
                    while (true)
                    {
                        try
                        {
                            Console.Write("Digite o ID do vinho que deseja remover: ");
                            idRemover = int.Parse(Console.ReadLine());
                            break;
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Erro: O ID deve ser um número inteiro.");
                        }
                    }
                    estoque.RemoverVinho(idRemover);
                    break;

                case "0":
                    Console.WriteLine("Encerrando...");
                    break;

                default:
                    Console.WriteLine("Opção inválida.");
                    break;
            }

        } while (opcao != "0");
    }
}
