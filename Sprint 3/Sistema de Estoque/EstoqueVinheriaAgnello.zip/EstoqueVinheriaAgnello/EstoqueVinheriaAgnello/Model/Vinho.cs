﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstoqueVinheriaAgnello.Model
{
    public class Vinho
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Tipo { get; set; }
        public int Safra { get; set; }
        public int Quantidade { get; set; }
        public decimal Preco { get; set; }

        public override string ToString()
        {
            return $"ID: {Id}, Nome: {Nome}, Tipo: {Tipo}, Safra: {Safra}, Quantidade: {Quantidade}, Preço: R${Preco:F2}";
        }
    }
}
