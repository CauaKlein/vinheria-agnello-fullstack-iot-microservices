﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EstoqueVinheriaAgnello.Model;

namespace EstoqueVinheriaAgnello.Services
{
    public class EstoqueVinheria
    {
        private ArrayList vinhos = new ArrayList();
        private int contadorId = 1;

        public void CadastrarVinho(string nome, string tipo, int safra, int quantidade, decimal preco)
        {
            Vinho vinho = new Vinho()
            {
                Id = contadorId++,
                Nome = nome,
                Tipo = tipo,
                Safra = safra,
                Quantidade = quantidade,
                Preco = preco
            };
            vinhos.Add(vinho);
        }

        public void EntradaEstoque(int id)
        {
            foreach (Vinho vinho in vinhos)
            {
                if (vinho.Id == id)
                {
                    int quantidade = 0;

                    while (true)
                    {
                        Console.WriteLine("Escolha a quantidade para entrada:");
                        Console.WriteLine("1 - Adicionar +1");
                        Console.WriteLine("2 - Adicionar +10");
                        Console.WriteLine("3 - Digitar valor personalizado");
                        Console.Write("Opção: ");

                        string opcao = Console.ReadLine();

                        if (opcao == "1")
                        {
                            quantidade = 1;
                            break;
                        }
                        else if (opcao == "2")
                        {
                            quantidade = 10;
                            break;
                        }
                        else if (opcao == "3")
                        {
                            Console.Write("Digite a quantidade personalizada: ");
                            try
                            {
                                quantidade = int.Parse(Console.ReadLine());
                                break;
                            }
                            catch (FormatException)
                            {
                                Console.WriteLine("Erro: Digite um número válido.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Opção inválida. Tente novamente.");
                        }
                    }

                    vinho.Quantidade += quantidade;
                    Console.WriteLine("Entrada realizada com sucesso.");
                    return;
                }
            }

            Console.WriteLine("Vinho não encontrado!");
        }


        public void SaidaEstoque(int id)
        {
            foreach (Vinho vinho in vinhos)
            {
                if (vinho.Id == id)
                {
                    int quantidade = 0;

                    while (true)
                    {
                        Console.WriteLine("Escolha a quantidade para saída:");
                        Console.WriteLine("1 - Remover -1");
                        Console.WriteLine("2 - Remover -10");
                        Console.WriteLine("3 - Digitar valor personalizado");
                        Console.Write("Opção: ");

                        string opcao = Console.ReadLine();

                        if (opcao == "1")
                        {
                            quantidade = 1;
                            break;
                        }
                        else if (opcao == "2")
                        {
                            quantidade = 10;
                            break;
                        }
                        else if (opcao == "3")
                        {
                            Console.Write("Digite a quantidade personalizada: ");
                            try
                            {
                                quantidade = int.Parse(Console.ReadLine());
                                break;
                            }
                            catch (FormatException)
                            {
                                Console.WriteLine("Erro: Digite um número válido.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Opção inválida. Tente novamente.");
                        }
                    }

                    if (vinho.Quantidade >= quantidade)
                    {
                        vinho.Quantidade -= quantidade;
                        Console.WriteLine("Saída realizada com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Estoque insuficiente!");
                    }
                    return;
                }
            }

            Console.WriteLine("Vinho não encontrado!");
        }


        public void ListarVinhos()
        {
            foreach (Vinho vinho in vinhos)
            {
                Console.WriteLine(vinho);
            }
        }

        public void AtualizarVinho(int id)
        {
            foreach (Vinho vinho in vinhos)
            {
                if (vinho.Id == id)
                {
                    Console.WriteLine("\n--- Dados atuais ---");
                    Console.WriteLine(vinho);

                    Console.WriteLine("\nQual campo deseja atualizar?");
                    Console.WriteLine("1 - Nome");
                    Console.WriteLine("2 - Tipo");
                    Console.WriteLine("3 - Safra");
                    Console.WriteLine("4 - Preço");
                    Console.Write("Escolha uma opção: ");
                    string escolha = Console.ReadLine();

                    try
                    {
                        switch (escolha)
                        {
                            case "1":
                                Console.Write("Novo nome: ");
                                vinho.Nome = Console.ReadLine();
                                break;
                            case "2":
                                Console.Write("Novo tipo: ");
                                vinho.Tipo = Console.ReadLine();
                                break;
                            case "3":
                                Console.Write("Nova safra: ");
                                vinho.Safra = int.Parse(Console.ReadLine());
                                break;
                            case "4":
                                Console.Write("Novo preço: ");
                                vinho.Preco = decimal.Parse(Console.ReadLine());
                                break;

                            default:
                                Console.WriteLine("Opção inválida.");
                                return;
                        }

                        Console.WriteLine("Vinho atualizado com sucesso!");
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Erro: valor inválido digitado.");
                    }

                    return;
                }
            }

            Console.WriteLine("Vinho não encontrado!");
        }

        public void RemoverVinho(int id)
        {
            foreach (Vinho vinho in vinhos)
            {
                if (vinho.Id == id)
                {
                    vinhos.Remove(vinho);
                    Console.WriteLine("Vinho removido do estoque.");
                    return;
                }
            }
            Console.WriteLine("Vinho não encontrado!");
        }
    }
}
